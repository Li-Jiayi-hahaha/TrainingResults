import random
import matplotlib.pyplot as plt

lst = []

for i in range(10):
	lst.append(random.randint(0, 100))



plt.plot(lst)

plt.savefig("figure.png")
print("fig renewed.")
